from PyQt5 import QtCore
import logging
import traceback
from core.scrap import ExchangeRateAPIClient
from core.graphic import NBUExchangeRates
from typing import List
from datetime import date
import time


def validate_rates(dates: List[date], rates: List[float], min_points=5, max_consecutive_missing=2,
                   max_missing_ratio=0.2) -> bool:
    if dates is None or rates is None:
        logging.warning("Даты или курсы равны None")
        return False

    if len(dates) < min_points or len(rates) < min_points:
        logging.warning("Недостаточно точек для построения графика")
        return False

    missing_count = 0
    consecutive_missing = 0

    for rate in rates:
        if rate is None or rate == 0:
            missing_count += 1
            consecutive_missing += 1
            if consecutive_missing > max_consecutive_missing:
                logging.warning("Слишком много подряд отсутствующих значений")
                return False
        else:
            consecutive_missing = 0

    if missing_count / len(rates) > max_missing_ratio:
        logging.warning("Слишком много отсутствующих значений в данных")
        return False

    return True


class ChartWorker(QtCore.QThread):
    finished = QtCore.pyqtSignal(object, object)  # даты и курсы
    error = QtCore.pyqtSignal(str)

    def __init__(self, currency_code: str, days: int = 30, timeout: int = 30) -> None:
        super().__init__()
        self.currency_code = currency_code
        self.days = days
        self.timeout = timeout
        self._start_time = None

    def run(self) -> None:
        self._start_time = time.time()
        try:
            nbu = NBUExchangeRates(currency_code=self.currency_code)

            # Проверка таймаута вручную, если выполнение заняло слишком много времени — прервать
            dates, rates = nbu.get_rates(days=self.days)

            elapsed = time.time() - self._start_time
            if elapsed > self.timeout:
                self.error.emit("Перевищено час очікування відповіді сервера (графік)")
                return

            if not validate_rates(dates, rates):
                self.error.emit("Недостатньо даних для побудови графіка.")
                return

            self.finished.emit(dates, rates)

        except Exception as e:
            logging.error(f"ChartWorker error: {e}\n{traceback.format_exc()}")
            self.error.emit(f"Помилка при побудові графіка: {e}")


class RateWorker(QtCore.QThread):
    finished = QtCore.pyqtSignal(str)
    error = QtCore.pyqtSignal(str)

    def __init__(self, currency_code: str, scrapper: ExchangeRateAPIClient, timeout: int = 10) -> None:
        super().__init__()
        self.currency_code = currency_code
        self.scrapper = scrapper  # Передаём объект из главного потока
        self.timeout = timeout
        self._start_time = None

    def run(self) -> None:
        self._start_time = time.time()
        try:
            rate_data = self.scrapper.get_rate_to_uah(self.currency_code)
            elapsed = time.time() - self._start_time
            if elapsed > self.timeout:
                self.error.emit("Перевищено час очікування відповіді сервера (курс)")
                return

            text = f"Курс {rate_data['base']} → {rate_data['currency']}: {rate_data['rate']:.2f}"
            self.finished.emit(text)
        except Exception as e:
            logging.error(f"RateWorker error: {e}\n{traceback.format_exc()}")
            self.error.emit("Помилка при отриманні курсу.")
