import requests
from datetime import datetime


class ExchangeRateAPIClient:
    BASE_URL = "https://api.exchangerate-api.com/v4/latest"

    def __init__(self, base="USD"):
        self.base = base

    def get_symbols(self):
        url = f"{self.BASE_URL}/{self.base}"
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()

        # Пропускаем валюту UAH
        symbols = {code: code for code in data["rates"].keys() if code != "UAH"}

        return {"symbols": symbols}

    def get_rate_to_uah(self, base_currency):
        url = f"https://api.exchangerate-api.com/v4/latest/{base_currency}"
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()

        rate_to_uah = data.get("rates", {}).get("UAH")
        if rate_to_uah is None:
            raise ValueError(f"Курс {base_currency} к UAH не найден")

        return {
            "base": base_currency,
            "currency": "UAH",
            "rate": rate_to_uah,
            "date": data.get("date", "")
        }


if __name__ == "__main__":
    client = ExchangeRateAPIClient(base="UAH")

    symbols = client.get_symbols()
    print("Доступные валюты:", symbols)

    current = client.get_current_rates(symbols=["USD", "EUR"])
    print("Текущие курсы:", current)
