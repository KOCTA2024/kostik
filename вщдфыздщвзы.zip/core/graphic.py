import requests
from datetime import datetime, timedelta, date
import matplotlib.pyplot as plt
import logging
from typing import List, Tuple, Optional

class NBUExchangeRates:
    BASE_URL = "https://bank.gov.ua/NBUStatService/v1/statdirectory/exchange"

    def __init__(self, currency_code: str = "USD"):
        self.currency_code = currency_code

    def get_rates(self, days: int = 30) -> Tuple[Optional[List[date]], Optional[List[float]]]:
        end_date = datetime.now().date()
        start_date = end_date - timedelta(days=days)

        dates: List[date] = []
        rates: List[float] = []

        try:
            for day in range(days + 1):
                current_date = start_date + timedelta(days=day)
                date_str = current_date.strftime('%Y%m%d')
                url = f"{self.BASE_URL}?valcode={self.currency_code}&date={date_str}&json"

                response = requests.get(url)
                if response.status_code != 200:
                    logging.error(f"Ошибка HTTP {response.status_code} для даты {current_date}")
                    continue

                data = response.json()

                if data and isinstance(data, list):
                    rate = data[0].get('rate', None)
                    if rate is not None:
                        dates.append(current_date)
                        rates.append(rate)
                    else:
                        logging.warning(f"Нет курса для {self.currency_code} на дату {current_date}")
                else:
                    logging.warning(f"Пустой или некорректный ответ от NBU на дату {current_date}")

            if not dates or not rates:
                logging.error("Ошибка: нет данных для выбранного периода")
                return None, None

            return dates, rates

        except Exception as e:
            logging.error(f"Ошибка при запросе данных NBU: {e}", exc_info=True)
            return None, None

    def plot_rates(self, dates: List[date], rates: List[float]) -> None:
        if not dates or not rates:
            logging.error("Нет данных для построения графика")
            return

        plt.figure(figsize=(12, 6))
        plt.plot(dates, rates, marker='o', linestyle='-', color='blue')
        plt.title(f'Курс {self.currency_code} до UAH (данные НБУ)', fontsize=14)
        plt.xlabel('Дата', fontsize=12)
        plt.ylabel(f'Курс (UAH за 1 {self.currency_code})', fontsize=12)
        plt.xticks(rotation=45)
        plt.grid(True)
        plt.tight_layout()
        plt.show()

    def get_rates_for_period(self, start_date: date, end_date: date) -> Tuple[Optional[List[date]], Optional[List[float]]]:
        delta = (end_date - start_date).days
        if delta < 0:
            logging.error("Неверный период: начальная дата позже конечной")
            return None, None

        return self.get_rates(days=delta)

# Пример использования:
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    nbu = NBUExchangeRates("USD")
    dates, rates = nbu.get_rates(days=30)
    if dates and rates:
        nbu.plot_rates(dates, rates)
